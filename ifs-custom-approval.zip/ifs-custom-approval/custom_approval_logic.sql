-- File: custom_approval_logic.sql

-- Package Specification
CREATE OR REPLACE PACKAGE custom_approval_logic AS
  PROCEDURE initiate_approval(p_order_id IN NUMBER);
  FUNCTION check_approval_status(p_order_id IN NUMBER) RETURN VARCHAR2;
END custom_approval_logic;
/

-- Package Body
CREATE OR REPLACE PACKAGE BODY custom_approval_logic AS

  PROCEDURE initiate_approval(p_order_id IN NUMBER) IS
  BEGIN
    -- Insert logic to create approval records
    INSERT INTO custom_approval_table (order_id, status, created_date)
    VALUES (p_order_id, 'PENDING', SYSDATE);
  END initiate_approval;

  FUNCTION check_approval_status(p_order_id IN NUMBER) RETURN VARCHAR2 IS
    v_status VARCHAR2(50);
  BEGIN
    SELECT status INTO v_status
    FROM custom_approval_table
    WHERE order_id = p_order_id;

    RETURN v_status;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 'NOT FOUND';
  END check_approval_status;

END custom_approval_logic;
/
