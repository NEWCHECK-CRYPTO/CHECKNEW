# IFS Custom Approval Logic

This is a sample PL/SQL package for custom approval handling in IFS ERP.
